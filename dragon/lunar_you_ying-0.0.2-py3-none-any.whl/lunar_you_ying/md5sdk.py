import hashlib


class MD5SDK:

    @staticmethod
    def str_to_md5_utf8_upper(string):
        m = hashlib.md5()
        m.update(string.encode("utf8"))
        return m.hexdigest().upper()

    @staticmethod
    def str_to_md5_gbk_upper(string):
        m = hashlib.md5(string.encode(encoding='gb2312'))
        return m.hexdigest().upper()
