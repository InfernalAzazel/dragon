import json
import random
import string

import aiohttp
import requests
import urllib3.contrib.pyopenssl

from lunar_you_ying.md5sdk import MD5SDK


class EWechatSDK:

    # 构造函数
    def __init__(self, corpid, corpsecret):
        self.corpid = corpid
        self.corpsecret = corpsecret
        self.url_gettoken = f'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={corpid}&corpsecret={corpsecret}'
        self.url_convert_to_openid = 'https://qyapi.weixin.qq.com/cgi-bin/user/convert_to_openid?'
        self.url_sendworkwxredpack = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/sendworkwxredpack'

    # 发送http请求
    async def sendRequest(self, method, request_url, data):
        if method == 'GET':
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(request_url, data=json.dumps(data)) as response:
                        try:
                            result = await response.json(encoding='utf-8')
                        except Exception as e:
                            return {}, e
            except Exception as e:
                return {}, e
        if method == 'POST':
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url, data=json.dumps(data)) as response:
                        try:
                            result = await response.json(encoding='utf-8')
                        except Exception as e:
                            return {}, e
            except Exception as e:
                return {}, e
        if method == 'XML':
            try:
                urllib3.contrib.pyopenssl.inject_into_urllib3()
                res = requests.post(request_url, data=data.encode(encoding='utf-8'),
                                    cert=('apiclient_cert.pem', 'apiclient_key.pem'))
                result = res.text
            except Exception as e:
                return {}, e
        return result, None

    # 发送http请求
    async def sendRequestXml(self, request_url, data, cert):
        try:
            urllib3.contrib.pyopenssl.inject_into_urllib3()
            res = requests.post(request_url, data=data.encode(encoding='utf-8'),
                                cert=cert)
            result = res.text
        except Exception as e:
            return {}, e
        return result, None

    # 获取 token
    async def getToken(self):
        """
        获取 token 认证

        :return: res, err
        """
        res, err = await self.sendRequest('GET', self.url_gettoken, data={})
        if err is not None:
            return {}, err
        if res['errcode'] != 0:
            return {}, res
        return res['access_token'], None

    # 成员 userid 转换 openid
    async def getConvertToOpenid(self, userid):
        """
        成员 userid 转换 openid

        :param userid: 成员id
        :return: openid
        """
        token, err, = await self.getToken()
        if err is not None:
            return {}, err
        res, err = await self.sendRequest('POST', self.url_convert_to_openid + f'access_token={token}', data={
            'userid': userid
        })
        if err is not None:
            return {}, err
        if res['errcode'] != 0:
            return {}, res
        return res['openid'], None

    # 发放企业红包
    async def sendWorkWXRedPack(self, agentid, secret, key, mch_billno, mch_id, userid, total_amount,
                                wishing, act_name, remark, cert=('apiclient_cert.pem', 'apiclient_key.pem'),
                                debug=False):
        """
        发放企业红包

        :param key: 微信支付 key 秘钥
        :param agentid: 企业微信支付应用 ID 值
        :param secret:  企业微信支付应用 secret 值
        :param mch_billno:  商户订单号   是   123456  String(28)  商户订单号（每个订单号必须唯一。取值范围：0~9，a~z，A~Z）.接口根据商户订单号支持重入，如出现超时可再调用。组成参考：mch_id+yyyymmdd+10位一天内不能重复的数字
        :param mch_id:  商户号 是   10000098    String(32)  微信支付分配的商户号
        :param userid:   成员 userid    是    2605541
        :param total_amount:    金额  是   1000    int 金额，单位分，单笔最小金额默认为1元
        :param wishing: 红包祝福语	是   感谢您参加猜灯谜活动，祝您元宵节快乐！ String(128) 红包祝福语
        :param act_name:    项目名称    是   猜灯谜抢红包活动    String(32)  项目名称
        :param remark:  备注  是   猜越多得越多，快来抢！ String(256) 备注信息
        :param debug: 打印发送与接收信息 默认 false
        :param cert: API 证书 ('apiclient_cert.pem', 'apiclient_key.pem')
        :return: xml, err
        """
        re_openid, err = await self.getConvertToOpenid(userid)
        if err is not None:
            return {}, err

        nonce_str = ''.join(random.sample(string.ascii_letters + string.digits, 32)).upper()  # 随机32位字符串
        wxappid = self.corpid
        stringA = f'act_name={act_name}&mch_billno={mch_billno}&mch_id={mch_id}&nonce_str={nonce_str}&re_openid={re_openid}&total_amount={total_amount}&wxappid={wxappid}'
        stringSignTemp = f'{stringA}&secret={secret}'
        workwx_sign = MD5SDK.strToMD5Upper(stringSignTemp)  # 企业微信签名算法
        if debug:
            print('企业微信签名算法', stringSignTemp)
            print('企业微信签名算法MD5加密', workwx_sign)

        stringA = f'act_name={act_name}' \
                  f'&agentid={agentid}' \
                  f'&mch_billno={mch_billno}' \
                  f'&mch_id={mch_id}' \
                  f'&nonce_str={nonce_str}' \
                  f'&re_openid={re_openid}' \
                  f'&remark={remark}' \
                  f'&total_amount={total_amount}' \
                  f'&wishing={wishing}' \
                  f'&workwx_sign={workwx_sign}' \
                  f'&wxappid={wxappid}'
        stringSignTemp = f'{stringA}&key={key}'
        sign = MD5SDK.strToMD5Upper(stringSignTemp)  # 微信支付签名算法 需要所有字段除 sign 外
        if debug:
            print('微信支付签名算法', stringSignTemp)
            print('微信支付签名算法MD5加密', sign)

        xml = f"""
          <xml>
                <nonce_str>{nonce_str}</nonce_str>
                <sign>{sign}</sign>
                <mch_billno>{mch_billno}</mch_billno>
                <mch_id>{mch_id}</mch_id>
                <wxappid>{wxappid}</wxappid>
                <agentid>{agentid}</agentid>
                <re_openid>{re_openid}</re_openid>
                <total_amount>{total_amount}</total_amount> 
                <wishing>{wishing}</wishing>
                <act_name>{act_name}</act_name>
                <remark>{remark}</remark>
                <workwx_sign>{workwx_sign}</workwx_sign>
            </xml>
        """

        res, err = await self.send_request_xml(self.url_sendworkwxredpack, data=xml, cert=cert)
        if err is not None:
            return {}, err
        if debug:
            print(xml)
            print(res)
        return res, None
