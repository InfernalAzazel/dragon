import hashlib
import json
from typing import List

import aiohttp
from loguru import logger


class JDSDK:

    # 构造函数
    def __init__(self, appId, entryId, api_key, retry_if_limited=True):
        """
        简道云支持库

        :param appId: 应用ID
        :param entryId: 表单ID
        :param api_key: 简道云API秘钥
        :param retry_if_limited: 当接口被限制后是否重发 默认 True
        """
        self.url_get_widgets = 'https://www.jiandaoyun.com/api/v1/app/' + appId + '/entry/' + entryId + '/widgets'
        self.url_get_data = 'https://www.jiandaoyun.com/api/v2/app/' + appId + '/entry/' + entryId + '/data'
        self.url_retrieve_data = 'https://www.jiandaoyun.com/api/v2/app/' + appId + '/entry/' + entryId + '/data_retrieve'
        self.url_update_data = 'https://www.jiandaoyun.com/api/v3/app/' + appId + '/entry/' + entryId + '/data_update'
        self.url_create_data = 'https://www.jiandaoyun.com/api/v3/app/' + appId + '/entry/' + entryId + '/data_create'
        self.url_delete_data = 'https://www.jiandaoyun.com/api/v1/app/' + appId + '/entry/' + entryId + '/data_delete'
        self.api_key = api_key
        self.retry_if_limited = retry_if_limited

    # 带有认证信息的请求头
    def getReqHeader(self):
        return {
            'Authorization': 'Bearer ' + self.api_key,
            'Content-Type': 'application/json;charset=utf-8'
        }

    # 签名
    @staticmethod
    def getSignature(nonce, secret, payload, timestamp):
        """
        解码签名-简道云 WEBHook

        :param nonce:
        :param secret:
        :param payload:
        :param timestamp:
        :return: result String
        """
        content = ':'.join([nonce, payload, secret, timestamp]).encode('utf-8')
        m = hashlib.sha1()
        m.update(content)
        return m.hexdigest()

    # 发送http请求
    async def sendRequest(self, method, request_url, data):
        headers = self.getReqHeader()
        if method == 'GET':
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(request_url, data=json.dumps(data), headers=headers) as response:
                        try:
                            status = response.status
                            result = await response.json(encoding='utf-8')
                        except Exception as e:
                            return {}, e
            except Exception as e:
                return {}, e
        if method == 'POST':
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url, data=json.dumps(data), headers=headers, ) as response:
                        try:
                            status = response.status
                            result = await response.json(encoding='utf-8')
                        except Exception as e:
                            return {}, e
            except Exception as e:
                return {}, e

        if status >= 400:
            if result['code'] == 8303 and self.retry_if_limited:
                return await self.sendRequest(method, request_url, data)
            else:
                return {}, result
        else:
            return result, None

    # 自动实例化 简道云API对象
    @staticmethod
    def autoInit(appIdList: List[str], entryIdList: List[str], apiKey: str, retryIfLimited=True):
        """
        自动实例化 简道云API对象

        :param appIdList: Array
        :param entryIdList: Array
        :param apiKey: Str
        :param retryIfLimited: 当接口被限制后是否重发 默认 True
        :return: Array
        """
        result = []
        if len(appIdList) != len(entryIdList):
            return
        for i in range(len(appIdList)):
            result.append(
                JDSDK(appId=appIdList[i], entryId=entryIdList[i], api_key=apiKey, retry_if_limited=retryIfLimited))
        return result

    # 获取表单字段
    async def getFormWidgets(self):
        """
               获取表单字段

               返回 widgets


               widgets[].items	仅子表单控件有；数组里包含了每个子控件的信息

               widgets[].label	控件标题

               widgets[].name	字段名（设置了字段别名则采用别名，未设置则采用控件ID）

               widgets[].type	控件类型；每种控件类型都有对应的数据类型

               :return: result, err

        """
        result, err = await self.sendRequest('POST', self.url_get_widgets, {})
        if err is not None:
            return {}, err
        return result['widgets'], None

    # 根据条件获取表单中的数据
    async def getFormData(self, dataId='', limit=10, fields=[], data_filter={}):
        """
        查询表单多条数据

        可以不带参，默认查询 10条

        :param dataId:      String	上一次查询数据结果的最后一条数据的ID，没有则留空
        :param fields:      Array   数据筛选器
        :param data_filter: JSON	需要查询的数据字段
        :param limit:       Number	查询的数据条数，1~100，默认10
        :return: result, err
        """
        result, err = await self.sendRequest('POST', self.url_get_data, {
            'data_id': dataId,
            'limit': limit,
            'fields': fields,
            'filter': data_filter
        })
        if err is not None:
            return {}, err
        return result['data'], None

    # 获取表单中满足条件的所有数据
    async def getAllData(self, fields, data_filter, label=''):
        """
        查询表单中满足条件的所有数据

        :param fields:          Array   需要查询的数据字段
        :param data_filter:     JSON	数据筛选器
        :param label:           String
        :return: result, err
        """

        form_data = []

        # 递归取下一页数据
        async def get_next_page(dataId):
            data, err = await self.get_form_data(dataId, 100, fields, data_filter)
            if err is not None:
                return {}, err
            if data:
                for v in data:
                    form_data.append(v)
                if label != '':
                    logger.info(f'[{label}] 读取累计 {len(form_data)} 数量 ..')
                dataId = data[len(data) - 1]['_id']
                await get_next_page(dataId)

        await get_next_page('')
        return form_data, None

    # 检索一条数据
    async def retrieveData(self, dataId):
        """
        检索一条数据

        :param dataId: string
        :return: result, err
        """
        result, err = await self.sendRequest('POST', self.url_retrieve_data, {
            'data_id': dataId
        })
        if err is not None:
            return {}, err
        return result['data'], err

    # 创建一条数据
    async def createData(self, data, is_start_workflow=False, is_start_trigger=False):
        """
        创建一条数据

        :param data:                JSON   数据内容
        :param is_start_workflow:   Bool	是否发起流程（仅流程表单有效）	false
        :param is_start_trigger:    Bool	是否触发智能助手	false
        :return: result, err
        """
        result, err = await self.sendRequest('POST', self.url_create_data, {
            'data': data,
            'is_start_workflow': is_start_workflow,
            'is_start_trigger': is_start_trigger
        })
        if err is not None:
            return {}, err
        return result['data'], err

    # 更新数据
    async def updateData(self, dataId, data, is_start_trigger=False):
        """
         更新数据

         :param dataId:              String	数据ID
         :param data:                JSON	数据内容，其他同新建单条数据接口，子表单需要注明子表单数据ID
         :param is_start_trigger:    Bool	是否触发智能助手  false
         :return: result, err
         """
        result, err = await self.sendRequest('POST', self.url_update_data, {
            'data_id': dataId,
            'data': data,
            'is_start_trigger': is_start_trigger,
        })
        if err is not None:
            return {}, err
        return result['data'], err

    # 删除数据
    async def deleteData(self, dataId, is_start_trigger=False):
        """
        删除数据

        :param dataId:              String	数据ID
        :param is_start_trigger:	Bool	是否触发智能助手	false
        :return: result, err
       """
        result, err = await self.sendRequest('POST', self.url_delete_data, {
            'data_id': dataId,
            'is_start_trigger': is_start_trigger,
        })
        if err is not None:
            return {}, err
        return result, err

    # 查询并更新一条
    async def queryUpdateDataOne(self, data, data_filter={}, non_existent_create=False, is_start_workflow=False,
                                 is_start_trigger=False):
        """
        查询并更新一条

        创建数据支持 发起流程 触发智能助手

        更新数据支持 触发智能助手

        :param data: JSON 数据
        :param data_filter: Array 数据筛选器
        :param non_existent_create: Bool 如果不存在则创建 false
        :param is_start_workflow: Bool 是否发起流程（仅流程表单有效） false
        :param is_start_trigger: Bool 是否触发智能助手 false
        :return: result, err
        """
        result, err = await self.getFormData(data_filter=data_filter)
        if err is not None:
            return {}, err
        if not result:
            if non_existent_create:
                result, err = await self.createData(
                    data=data, is_start_workflow=is_start_workflow,
                    is_start_trigger=is_start_trigger)
                if err is not None:
                    return {}, err
                return result, None
        else:
            result, err = await self.updateData(dataId=result[0]['_id'], data=data, is_start_trigger=is_start_trigger)
            if err is not None:
                return {}, err
            return result, None

    # 查询并删除一条
    async def queryDeleteOne(self, data_filter={}):
        """
        查询并删除一条

        :param data_filter: Array 数据筛选器
        :return: result, err
        """
        result, err = await self.getFormData(data_filter=data_filter)
        if err is not None:
            return {}, err
        if result:
            result, err = await self.deleteData(dataId=result[0]['_id'])
            if err is not None:
                return {}, err
        return result, None
