import hashlib


class MD5SDK:

    @staticmethod
    def strToMD5Upper(string):
        m = hashlib.md5()
        m.update(string.encode("utf8"))
        return m.hexdigest().upper()

    @staticmethod
    def strToMD5GBKUpper(string):
        m = hashlib.md5(string.encode(encoding='gb2312'))
        return m.hexdigest().upper()
